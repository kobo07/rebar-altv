import * as alt from 'alt-server';
import { useRebar } from '@Server/index.js';

const Rebar = useRebar();

import nodemailer from 'nodemailer';
import crypto from 'crypto';


import { AuthEvents } from '../shared/authEvents.js';
import { Account } from '@Shared/types/account.js';
import { useTranslate } from '@Shared/translate.js';
import '../translate/index.js';
const { t } = useTranslate('en');










let verificationCodes = {}; // 存储验证码及其过期时间

// 配置邮件发送
const transporter = nodemailer.createTransport({
    service: 'QQ', // 使用QQ邮箱
    port: 465, // SMTP端口
    secure: true, // 启用SSL
    auth: {
        user: '1157394401@qq.com', // QQ邮箱账号
        pass: 'dalcjejcpwcqijjc', // QQ邮箱SMTP授权码
    },
});

// 生成验证码
function generateVerificationCode() {
    return crypto.randomBytes(3).toString('hex').toUpperCase(); // 生成6位验证码
}

// 定时清理过期验证码
setInterval(() => {
    const now = Date.now();
    for (const email in verificationCodes) {
        if (verificationCodes[email].expirationTime < now) {
            delete verificationCodes[email];
        }
    }
}, 60 * 1000 * 10); // 每10分钟检查一次

alt.onClient(AuthEvents.toServer.sendVerificationCode, async (player: alt.Player, email: string) => {
    
    const code = generateVerificationCode();
    const expirationTime = Date.now() + 10 * 60 * 1000; // 验证码有效时间10分钟
    verificationCodes[email] = { code, expirationTime };

    const mailOptions = {
        from: '"蛋城客服团队" <1157394401@qq.com>', // 修改发件人名称
        to: email,
        subject: '蛋城 - 账户注册验证码',
        text: `亲爱的用户，\n\n感谢您注册蛋城！您的验证码是：${code}，有效期为10分钟。请在有效期内使用验证码完成注册。\n\n如有任何问题，请联系我们的客服团队。\n\n祝好，\n蛋城客服团队`,
        html: `<p>亲爱的用户，</p>
               <p>感谢您注册蛋城！您的验证码是：<strong>${code}</strong>，有效期为10分钟。请在有效期内使用验证码完成注册。</p>
               <p>如有任何问题，请联系我们的客服团队。</p>
               <p>祝好，<br>蛋城客服团队</p>`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        const webview = Rebar.player.useWebview(player);
        if (error) {
            return webview.emit(AuthEvents.fromServer.showmessage, '发送验证码失败');
        }
        webview.emit(AuthEvents.fromServer.showmessage, '验证码发送成功');
    });
});












type AccountData = { token: string } & Account;

const loginCallbacks: Array<(player: alt.Player) => void> = [];
const loggedInPlayers: Map<number, string> = new Map<number, string>();
const sessionKey = 'can-authenticate';
const db = Rebar.database.useDatabase();

function setAccount(player: alt.Player, account: Account) {
    Rebar.document.account.useAccountBinder(player).bind(account);
    Rebar.player.useWebview(player).hide('Auth');
    Rebar.player.useNative(player).invoke('triggerScreenblurFadeOut', 1000);
    player.deleteMeta(sessionKey);
    player.dimension = 0;
    player.emit(AuthEvents.toClient.cameraDestroy);
    loggedInPlayers[player.id] = account._id;
    for (let cb of loginCallbacks) {
        cb(player);
    }
}

function getHash(player: alt.Player) {
    return Rebar.utility.sha256(
        player.ip + player.hwidHash + player.hwidExHash + player.socialID + player.socialClubName
    );
}

async function updateRememberMe(player: alt.Player, _id: string) {
    await db.update<AccountData>({ _id, token: getHash(player) }, Rebar.database.CollectionNames.Accounts);
}

async function tryRememberMe(player: alt.Player): Promise<boolean> {
    const token = getHash(player);
    const account = await db.get<AccountData>({ token }, Rebar.database.CollectionNames.Accounts);
    if (!account) {
        return false;
    }

    setAccount(player, account);
    return true;
}

async function handleLogin(player: alt.Player, email: string, password: string, rememberMe: boolean) {
    if (!player.getMeta(sessionKey)) {
        player.kick(t('auth.kick.sessionKey'));
        return;
    }

    const account = await db.get<Account>({ email }, Rebar.database.CollectionNames.Accounts);
    const webview = Rebar.player.useWebview(player);
    if (!account) {
        webview.emit(AuthEvents.fromServer.invalidLogin);
        return;
    }

    if (!Rebar.utility.password.check(password, account.password)) {
        webview.emit(AuthEvents.fromServer.invalidLogin);
        return;
    }

    if (Object.values(loggedInPlayers).includes(account._id)){
        player.kick(t('auth.kick.alreadyLoggedIn'));
        return;
    }

    if (rememberMe) {
        await updateRememberMe(player, account._id);
    }

    setAccount(player, account);
}

async function handleRegister(player: alt.Player, email: string, password: string, verificationcode:string) {
    if (!player.getMeta(sessionKey)) {
        player.kick(t('auth.kick.sessionKey'));
        return;
    }

    let account = await db.get<Account>({ email }, Rebar.database.CollectionNames.Accounts);
    const webview = Rebar.player.useWebview(player);
    if (account) {
        webview.emit(AuthEvents.fromServer.invalidRegister);
        webview.emit(AuthEvents.fromServer.showmessage, '该邮箱已被注册');
        return;
    }

    const _id = await db.create<Partial<Account>>(
        { email, password: Rebar.utility.password.hash(password) },
        Rebar.database.CollectionNames.Accounts
    );
    if (!_id) {
        webview.emit(AuthEvents.fromServer.invalidRegister);
        webview.emit(AuthEvents.fromServer.showmessage, '注册失败');
        return;
    }

    account = await db.get<Account>({ _id }, Rebar.database.CollectionNames.Accounts);
    if (!account) {
        webview.emit(AuthEvents.fromServer.invalidRegister);
        webview.emit(AuthEvents.fromServer.showmessage, '注册失败');
        return;
    }

    const verification = verificationCodes[email];
    if (!verification || verification.code !== verificationcode || Date.now() > verification.expirationTime) {
        webview.emit(AuthEvents.fromServer.invalidRegister);
        webview.emit(AuthEvents.fromServer.showmessage, '验证码不正确或已过期');
        return;
    }

    

    setAccount(player, account);
}

async function handleConnect(player: alt.Player) {
    const didLogin = await tryRememberMe(player);
    if (didLogin) {
        return;
    }

    player.dimension = player.id + 1;
    player.setMeta(sessionKey, true);
    player.emit(AuthEvents.toClient.cameraCreate);
    Rebar.player.useWebview(player).show('Auth', 'page');
    Rebar.player.useNative(player).invoke('triggerScreenblurFadeIn', 1000);
}

async function handleDisconnect(player: alt.Player) {
    delete loggedInPlayers[player.id];
}

alt.onClient(AuthEvents.toServer.login, handleLogin);
alt.onClient(AuthEvents.toServer.register, handleRegister);
alt.on('playerConnect', handleConnect);
alt.on('playerDisconnect', handleDisconnect);

export function useAuth() {
    function onLogin(callback: (player: alt.Player) => void) {
        loginCallbacks.push(callback);
    }

    return {
        onLogin,
    };
}

declare global {
    export interface ServerPlugin {
        ['auth-api']: ReturnType<typeof useAuth>;
    }
}

Rebar.useApi().register('auth-api', useAuth());
